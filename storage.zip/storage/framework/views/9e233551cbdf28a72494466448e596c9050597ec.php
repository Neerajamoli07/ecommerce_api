<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-6 padbot60 about_us_description"
         data-appear-top-offset='-100' data-animated='fadeInLeft'>
        <p>We empower WordPress developers with design-driven themes and a
            classy experience their clients will just love</p>
        <span>Gluten-free quinoa selfies carles, kogi gentrify retro marfa
					viral. Odd future photo booth flannel ethnic pug, occupy keffiyeh
					synth blue bottle tofu tonx iphone. Blue bottle 90вЂІs vice trust
					fund gastropub gentrify retro marfa viral.</span> <span>Sollicitudin,
					lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis
					sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a
					sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio
					tincidunt auctor a ornare odio.</span>
    </div>

    <div class="col-lg-6 col-md-6 col-sm-6 padbot30"
         data-appear-top-offset='-100' data-animated='fadeInRight'>
        <img class="about_img1"
             src="<?php echo e(url('images')); ?>/about_img1.jpg" alt=""/>
    </div>
</div>