<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-ss-12 padbot30">
    <div class="team_item center">
        <img class="team_foto"
             src="<?php echo e(url('images')); ?>/<?php echo e($image); ?>" alt=""/>
        <p><?php echo e($name); ?></p>
        <span><?php echo e($position); ?></span>
        <div class="team_social">
            <a href="javascript:void(0);"><i class="fa fa-facebook"></i></a> <a
                    href="javascript:void(0);"><i class="fa fa-twitter"></i></a> <a
                    href="javascript:void(0);"><i class="fa fa-linkedin"></i></a> <a
                    href="javascript:void(0);"><i class="fa fa-google-plus"></i></a>
        </div>
    </div>
</div>