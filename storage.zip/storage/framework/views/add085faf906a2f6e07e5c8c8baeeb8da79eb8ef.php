<!-- TOVAR MODAL CONTENT -->
<div id="modal-body" class="clearfix">
    <div id="tovar_content"></div>
    <div class="close_block"></div>
</div>
<!-- TOVAR MODAL CONTENT -->

<!-- SCRIPTS -->
<!--[if IE]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
<!--[if IE]>
<html class="ie" lang="en"> <![endif]-->

<script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/superfish.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/jquery.sticky.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/parallax.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/jquery.flexslider-min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/jquery.jcarousel.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/fancySelect.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/animate.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/myscript.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/js/customjs.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('/js/jquery.fancybox.js')); ?>" type="text/javascript"></script>
<script>
    if (top != self) top.location.replace(self.location.href);
</script>