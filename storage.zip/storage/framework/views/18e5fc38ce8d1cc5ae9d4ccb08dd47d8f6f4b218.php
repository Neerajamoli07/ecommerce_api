<!-- HOME -->
<section id="home" class="padbot0">

	<!-- TOP SLIDER -->
	<div class="flexslider top_slider">
		<ul class="slides">
			<li class="slide1">
				<!-- CONTAINER -->
				<div class="container">
					<div class="flex_caption1">
						<p class="title1 captionDelay2 FromTop">mega sell</p>
						<p class="title2 captionDelay3 FromTop">last week of sales</p>
					</div>
					<a class="flex_caption2" href="javascript:void(0);"><div
							class="middle">
							sale<span>shop</span>now
						</div></a>
					<div class="flex_caption3 slide_banner_wrapper">
						<a class="slide_banner slide1_banner1 captionDelay4 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner1.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner2 captionDelay5 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner2.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner3 captionDelay6 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner3.jpg" alt="" /></a>
					</div>
				</div>
				<!-- //CONTAINER -->
			</li>

			<li class="slide2">
				<!-- CONTAINER -->
				<div class="container">
					<div class="flex_caption1">
						<p class="title1 captionDelay2 FromTop">mega sell</p>
						<p class="title2 captionDelay3 FromTop">last week of sales</p>
					</div>
					<a class="flex_caption2" href="javascript:void(0);"><div
							class="middle">
							sale<span>shop</span>now
						</div></a>
					<div class="flex_caption3 slide_banner_wrapper">
						<a class="slide_banner slide1_banner1 captionDelay4 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner1.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner3 captionDelay5 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner3.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner2 captionDelay6 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner2.jpg" alt="" /></a>
					</div>
				</div>
				<!-- //CONTAINER -->
			</li>

			<li class="slide3">
				<!-- CONTAINER -->
				<div class="container">
					<div class="flex_caption1">
						<p class="title1 captionDelay2 FromTop">mega sell</p>
						<p class="title2 captionDelay3 FromTop">last week of sales</p>
					</div>
					<a class="flex_caption2" href="javascript:void(0);"><div
							class="middle">
							sale<span>shop</span>now
						</div></a>
					<div class="flex_caption3 slide_banner_wrapper">
						<a class="slide_banner slide1_banner3 captionDelay4 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner3.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner1 captionDelay5 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner1.jpg" alt="" /></a> <a
							class="slide_banner slide1_banner2 captionDelay6 FromBottom"
							href="javascript:void(0);"><img
							src="<?php echo e(url('images/slider')); ?>/slide1_baner2.jpg" alt="" /></a>
					</div>
				</div>
				<!-- //CONTAINER -->
			</li>
		</ul>
	</div>
	<!-- //TOP SLIDER -->
</section>
<!-- //HOME -->