<?php $__env->startComponent('mail::message'); ?>
# Email for activation account in Laravel CMS

Hello <?php echo e($user->name); ?>



Dear, <?php echo e($user->name); ?>

Please activate your account at : <?php echo e(url('user/activation', $user->link)); ?>


Thanks from,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
