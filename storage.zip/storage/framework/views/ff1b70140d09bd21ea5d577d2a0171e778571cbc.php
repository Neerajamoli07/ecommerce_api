<?php $__env->startSection('body'); ?>
    <div class="form-group">
        <?php echo Form::label('Slug', 'Slug:'); ?>

        <?php echo Form::text('slug',$product->slug,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Name', 'Name:'); ?>

        <?php echo Form::text('name',$product->name,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Description', 'Description:'); ?>

        <?php echo Form::textarea('description',$product->description,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Image'); ?>

        <a class="thumbnail">
            <img class="img-responsive" src="<?php echo e(asset('images/products/'.$product->a_img)); ?>"
                 height="45" width="35" alt="<?php echo e($product->a_img); ?>">
        </a>
    </div>
    <div class="form-group">
        <?php echo Form::label('Brand', 'Brand:'); ?>

        <?php echo Form::text('brand',$product->brands->brand,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Size', 'Size:'); ?>

        <?php echo Form::text('size',implode(",",$product->size->pluck("size")->all()),
                      ['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Category', 'Category:'); ?>

        <?php echo Form::text('cat_id',$product->category->cat,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Stock', 'Stock:'); ?>

        <?php echo Form::text('quantity',$product->quantity,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Price', 'Price:'); ?>

        <?php echo Form::text('price',$product->price,['class'=>'form-control', 'readonly' => 'true']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('Fresh Product Date', 'Fresh Product Date:'); ?>

        <?php echo Form::text('fresh_product_date',$product->fresh_product_date,['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <a href="<?php echo e(url('backend/articles')); ?>" class="btn btn-primary">Back</a>
    </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.tblTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>