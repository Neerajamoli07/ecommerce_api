<?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/admin')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-tachometer <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Dashboard <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/articles')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-pencil-square-o <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Product <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/users')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-user <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Manage Users <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/orders')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-shopping-cart <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Orders <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/brands')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-th-large <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Brands <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/category')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-list <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Categories <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/subcategory')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-list-alt <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>Subcategories <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.dropdown'); ?>
    <?php echo Helper::setActive('products'); ?>

    <?php $__env->slot('link'); ?><?php echo e(url('backend/products')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('m_icon'); ?>icon fa fa-table <?php $__env->endSlot(); ?>
    <?php $__env->slot('m_name'); ?>Manage Catalog <?php $__env->endSlot(); ?>
    <?php $__env->slot('s_icon'); ?>icon fa fa-pencil-square-o <?php $__env->endSlot(); ?>
    <?php $__env->slot('s_name'); ?>Edit Products <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (\Illuminate\Support\Facades\Blade::check('user')): ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/user')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-tachometer <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>User Dashboard <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/profile')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-eye <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>User Profile <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <?php $__env->startComponent('backend.link'); ?>
    <?php $__env->slot('link'); ?><?php echo e(url('backend/user-orders')); ?><?php $__env->endSlot(); ?>
    <?php $__env->slot('icon'); ?>icon fa fa-money <?php $__env->endSlot(); ?>
    <?php $__env->slot('name'); ?>My Orders <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>