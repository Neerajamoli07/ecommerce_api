<!-- SERVICES SECTION -->
		<section class="services_section">
			
			<!-- CONTAINER -->
			<div class="container">
				
				<!-- ROW -->
				<div class="row">
					<div class="col-lg-6 col-md-6 padbot60 services_section_description" data-appear-top-offset='-100' data-animated='fadeInLeft'>
						<p>We empower WordPress developers with design-driven themes and a classy experience their clients will just love</p>
						<span>Gluten-free quinoa selfies carles, kogi gentrify retro marfa viral. Odd future photo booth flannel ethnic pug, occupy keffiyeh synth blue bottle tofu tonx iphone. Blue bottle 90′s vice trust fund gastropub gentrify retro marfa viral</span>
					</div>
					
					<div class="col-lg-6 col-md-6 padbot30" data-appear-top-offset='-100' data-animated='fadeInRight'>
						
						<!-- ROW -->
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-3 col-xs-6 col-ss-12 padbot30">
								<div class="service_item">
									<div class="clearfix"><i class="fa fa-tablet"></i><p>Responsive Theme</p></div>
									<span>Thundercats squid single-origin coffee YOLO selfies disrupt, master cleanse semiotics letterpress typewriter.</span>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-3 col-xs-6 col-ss-12 padbot30">
								<div class="service_item">
									<div class="clearfix"><i class="fa fa-comments-o"></i><p>Free Support</p></div>
									<span>Thundercats squid single-origin coffee YOLO selfies disrupt, master cleanse semiotics letterpress typewriter.</span>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-3 col-xs-6 col-ss-12 padbot30">
								<div class="service_item">
									<div class="clearfix"><i class="fa fa-eye"></i><p>Retina Ready</p></div>
									<span>Thundercats squid single-origin coffee YOLO selfies disrupt, master cleanse semiotics letterpress typewriter.</span>
								</div>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-3 col-xs-6 col-ss-12 padbot30">
								<div class="service_item">
									<div class="clearfix"><i class="fa fa-cogs"></i><p>Easy Customize</p></div>
									<span>Thundercats squid single-origin coffee YOLO selfies disrupt, master cleanse semiotics letterpress typewriter.</span>
								</div>
							</div>
						</div><!-- //ROW -->
					</div>
				</div><!-- //ROW -->
			</div><!-- //CONTAINER -->
		</section><!-- //SERVICES SECTION -->