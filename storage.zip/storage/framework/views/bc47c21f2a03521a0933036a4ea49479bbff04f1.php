<!-- Footer -->
<footer class="app-footer">
    <div class="wrapper">
        <span class="pull-right">Admin Panel<a href="#"><i class="fa fa-long-arrow-up"></i></a></span>2020-21 Copyright.
    </div>
</footer>
<!-- End Footer -->

<div>
    <!-- Javascript Libs -->
    <script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
    <!-- Javascript -->
    <script type="text/javascript" src="<?php echo e(asset('/js/app-backend.js')); ?>"></script>
    <?php echo Rapyd::scripts(); ?>

</div>