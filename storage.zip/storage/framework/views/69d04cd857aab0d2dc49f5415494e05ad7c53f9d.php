<li class="menu">
    <a href="<?php echo e($link); ?>">
        <span class="<?php echo e($icon); ?>"></span><span class="title"><?php echo e($name); ?></span>
    </a>
</li>