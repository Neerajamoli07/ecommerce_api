<div class="col-lg-3 col-md-3 col-sm-3 col-xs-6 col-ss-12 padbot30">
    <div class="service_item">
        <div class="clearfix">
            <i class="fa fa-tablet"></i>
            <p><?php echo e($slot); ?></p>
        </div>
        <span>Thundercats squid single-origin coffee YOLO selfies disrupt,
                master cleanse semiotics letterpress typewriter.</span>
    </div>
</div>