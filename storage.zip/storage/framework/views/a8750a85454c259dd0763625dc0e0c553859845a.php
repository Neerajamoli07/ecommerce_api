<?php $__env->startSection('title',$title); ?>
<?php $__env->startSection('body'); ?>
    <?php if(isset($edit)): ?>
        <?php echo $edit; ?>

    <?php elseif(isset($filter)): ?>
        <?php echo $filter; ?>

        <?php echo $grid; ?>

    <?php else: ?>
        <?php echo $grid; ?>

    <?php endif; ?>
    <?php echo $__env->make('errors.error_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/tblTemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>