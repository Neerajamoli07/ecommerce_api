<?php $__env->startSection('content'); ?>
    <!-- BREADCRUMBS -->
    <section class="breadcrumb parallax margbot30"></section>
    <!-- //BREADCRUMBS -->


    <!-- PAGE HEADER -->
    <section class="page_header">

        <!-- CONTAINER -->
        <div class="container">
            <h3 class="pull-left">
                <b>About us</b>
            </h3>

            <div class="pull-right">
                <a href="women.html">Back to shop<i class="fa fa-angle-right"></i></a>
            </div>
        </div>
        <!-- //CONTAINER -->
    </section>
    <!-- //PAGE HEADER -->


    <!-- ABOUT US INFO -->
    <section class="about_us_info">

        <!-- CONTAINER -->
        <div class="container">

            <!-- ROW -->
        <?php echo $__env->make('partials/aboutinfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- //ROW -->

            <!-- ROW -->
            <div class="row services_wrapper padbot40"
                 data-appear-top-offset='-100' data-animated='fadeInUp'>
                <?php $__env->startComponent('partials/about'); ?>Responsive Theme <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('partials/about'); ?>Free Support <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('partials/about'); ?>Retina Ready <?php echo $__env->renderComponent(); ?>
                <?php $__env->startComponent('partials/about'); ?>Easy Customize <?php echo $__env->renderComponent(); ?>
            </div>
            <!-- //ROW -->


            <!-- ROW -->
            <div class="row team_wrapper padbot60" data-appear-top-offset='-100'
                 data-animated='fadeInUp'>

                <?php $__env->startComponent('partials/team'); ?>
                <?php $__env->slot('image'); ?>team/1.jpg <?php $__env->endSlot(); ?>
                <?php $__env->slot('name'); ?>Anna balashova <?php $__env->endSlot(); ?>
                <?php $__env->slot('position'); ?>Senior Manager <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('partials/team'); ?>
                <?php $__env->slot('image'); ?>team/2.jpg <?php $__env->endSlot(); ?>
                <?php $__env->slot('name'); ?>John James <?php $__env->endSlot(); ?>
                <?php $__env->slot('position'); ?>Manager <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('partials/team'); ?>
                <?php $__env->slot('image'); ?>team/3.jpg <?php $__env->endSlot(); ?>
                <?php $__env->slot('name'); ?>Kristi hogvard <?php $__env->endSlot(); ?>
                <?php $__env->slot('position'); ?>Manager <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('partials/team'); ?>
                <?php $__env->slot('image'); ?>team/4.jpg <?php $__env->endSlot(); ?>
                <?php $__env->slot('name'); ?>Nick Kovach <?php $__env->endSlot(); ?>
                <?php $__env->slot('position'); ?>Marketing <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>

            </div>
            <!-- //ROW -->
        </div>
        <!-- //CONTAINER -->
    </section>
    <!-- //ABOUT US INFO -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>