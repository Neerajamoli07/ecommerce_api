<?php

namespace Facades\App\Http\Routes;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Http\Routes\Register
 */
class Register extends Facade
{
    /**
     * Get the registered name of the component.
     *
     * @return string
     */
    protected static function getFacadeAccessor()
    {
        return 'App\Http\Routes\Register';
    }
}
